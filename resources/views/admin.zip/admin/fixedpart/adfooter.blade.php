<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Hairfactbd.com 2021 || Develop by DropDown Technology</span>
          </div>
        </div>
</footer>